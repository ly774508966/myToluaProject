//
//  tolua.h
//  tolua
//
//  Created by admin on 16/4/26.
//  Copyright © 2016年 topameng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface tolua : NSObject

@end
